// Google user login response
//   config: {
//     url: 'https://www.googleapis.com/oauth2/v2/userinfo',
//     method: 'GET',
//     userAgentDirectives: [ [Object] ],
//     paramsSerializer: [Function (anonymous)],
//     headers: {
//       'x-goog-api-client': 'gdcl/7.0.1 gl-node/18.17.0',
//       'Accept-Encoding': 'gzip',
//       'User-Agent': 'google-api-nodejs-client/7.0.1 (gzip)',
//       Authorization: 'Bearer ya29.a0AfB_byD20JIdEFGwtIMFAFhtQFCDI7bGRISUuq8eZgh5VvQMCDbeM3kfgRSsQIAk9YyLQKyHwbWaJDgvY3yejHnE2usc3BMkchRE5DO55exE4NooP8GnmtdumGvVXADYoLClMy32ogv4lJ3Bmq8w0s7qbQyIFwadlK1FaCgYKAUcSARISFQHGX2MiIunAxrEzeoVhivCNqSZuZg0171'
//     },
//     params: {},
//     validateStatus: [Function (anonymous)],
//     retry: true,
//     responseType: 'unknown',
//     errorRedactor: [Function: defaultErrorRedactor]
//   },
//   data: {
//     id: '102617276885568541577',
//     email: 'rakibhossen040@gmail.com',
//     verified_email: true,
//     name: 'Rakib hossen',
//     given_name: 'Rakib',
//     family_name: 'hossen',
//     picture: 'https://lh3.googleusercontent.com/a/ACg8ocInhM9C0ET9U-b12o81NaxdoeHV828_kS3LyPrjlnWznyE=s96-c',
//     locale: 'en-GB'
//   },
//   headers: {
//     'alt-svc': 'h3=":443"; ma=2592000,h3-29=":443"; ma=2592000',
//     'cache-control': 'no-cache, no-store, max-age=0, must-revalidate',
//     connection: 'close',
//     'content-encoding': 'gzip',
//     'content-type': 'application/json; charset=UTF-8',
//     date: 'Thu, 04 Jan 2024 16:45:00 GMT',
//     expires: 'Mon, 01 Jan 1990 00:00:00 GMT',
//     pragma: 'no-cache',
//     server: 'ESF',
//     'transfer-encoding': 'chunked',
//     vary: 'Origin, X-Origin, Referer',
//     'x-content-type-options': 'nosniff',
//     'x-frame-options': 'SAMEORIGIN',
//     'x-xss-protection': '0'
//   },
//   status: 200,
//   statusText: 'OK',
//   request: { responseURL: 'https://www.googleapis.com/oauth2/v2/userinfo' }

// DB_USER=account-management
// DB_PASSWORD=MDRG2pasOQjoNcWT
// DB_URL=mongodb+srv://account-management:MDRG2pasOQjoNcWT@simple-node-app.ybb3hyi.mongodb.net/
